---
title: "Repairing Word-External Onsetless Syllables during Late Childhood. "
collection: publications
excerpt: ''
date: 2021-09-01
venue: 'Proceedings of the 45th annual Boston University Conference on Language Development'
paperurl: 'https://pubmed.ncbi.nlm.nih.gov/31362301/'
citation: 'Repiso-Puigdelliura G. (2021). Repairing Word-External Onsetless Syllables during Late Childhood. In D. Dionne and Lee-Ann Vidal Covas (Eds.) <i>Proceedings of the 45th annual Boston University Conference on Language Development</i>. Sommerville, MA:Cascadilla Press pp. 639-651'
---
